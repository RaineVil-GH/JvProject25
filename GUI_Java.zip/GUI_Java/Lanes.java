package GUI_Java;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class Lanes {
	
	String id;
	List<Point2D> shape = new ArrayList<>();
	
	public Lanes() {
		
	}
	
	
	
}


