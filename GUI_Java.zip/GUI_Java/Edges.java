package GUI_Java;
import java.util.ArrayList;
import java.util.List;


public class Edges {
	String id;
	List<Lanes> lnlst = new ArrayList<>();
	public Edges() {}
}
