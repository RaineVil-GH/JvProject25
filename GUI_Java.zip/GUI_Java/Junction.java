package GUI_Java;

public class Junction {
	String id;
	double x;
	double y;
	
	public String tlId;
	TrafficLights tljunc;

	public Junction()  {
	
		}
	}