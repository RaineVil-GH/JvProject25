
public class TLPhase {
	
	public final double drt;
	public final String st;
	
	public TLPhase(double duration , String state) {
		this.drt = duration;
		this.st = state;
	}

}
