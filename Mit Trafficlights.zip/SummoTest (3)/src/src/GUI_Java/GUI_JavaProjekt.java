    package src.GUI_Java;
    import it.polito.appeal.traci.SumoTraciConnection;
    import src.Car;

    import java.awt.*;
    import java.awt.event.ActionEvent;
    import java.io.File;
    import javax.swing.*;
    import javax.swing.border.Border;
    import javax.swing.filechooser.FileNameExtensionFilter;
    import java.awt.event.ActionListener;


    public class GUI_JavaProjekt {

        private JFrame frame;
        private JPanel center;

        private Car cCar;
        private SumoTraciConnection conn;


        public GUI_JavaProjekt(Car cCar, SumoTraciConnection conn) {
            this.cCar = cCar;
            this.conn = conn;
        }

        private boolean fileLoaded = false;
        int steps = 0;

        //private VehicleManager vMngr = new VehicleManager();
        public MapVisual mv;
        //	public SimuVisual smV;




        public GUI_JavaProjekt() {
            this.cCar = new Car("c");

        }

        //StartingMethode for the GUI
        public void startFrame() {
            frame = new JFrame("GUI Network");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1000, 600);

            JPanel mainpnl = new JPanel(new BorderLayout());
            JPanel dbP = new JPanel(new BorderLayout());
            JPanel ctrP = new JPanel();
            ctrP.setLayout(new BoxLayout(ctrP, BoxLayout.Y_AXIS));
            center = new JPanel(new BorderLayout());

            dbP.setPreferredSize(new Dimension(100, 0));
            ctrP.setPreferredSize(new Dimension(100, 0));


            mainpnl.add(dbP, BorderLayout.WEST);
            mainpnl.add(center, BorderLayout.CENTER);
            mainpnl.add(ctrP, BorderLayout.EAST);

            frame.setContentPane(mainpnl);
            //Titles
            dbP.add(new JLabel("Dashboarder"), BorderLayout.NORTH);
            ctrP.add(new JLabel("ControlPanel"), BorderLayout.NORTH);

            //ControlPanel
            //Add Vehicle

            JButton veh = new JButton("Add Object");
            ctrP.add(veh);

            veh.addActionListener(e -> {
                JFrame vFrm = new JFrame("Choose Vehicle");
                JButton car = new JButton("Add Car");
                JButton bus = new JButton("Add Bus");
                JButton motorcyclist = new JButton("Add Motorcyclist");
                JButton cyclist = new JButton("Add Cyclist");
                JButton pedestrian = new JButton("Add Pedestrian");

                JPanel routenPanel = new JPanel(new BorderLayout());
                routenPanel.setBorder(BorderFactory.createTitledBorder("Select Route"));

                /*JComboBox<String> routeDropdown = new JComboBox<>(Car.rout);
                routePanel.add(routeDropdown, BorderLayout.CENTER);
*/
                vFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                vFrm.setSize(500, 300);

                JPanel panel = new JPanel();
                panel.setLayout(new GridLayout(2, 3, 10, 10));

                panel.add(car);
                panel.add(bus);
                panel.add(motorcyclist);
                panel.add(cyclist);
                panel.add(pedestrian);

                vFrm.setContentPane(panel);
                vFrm.setLocationRelativeTo(frame);
                vFrm.setVisible(true);

                // --- Add Car ---
                /*car.addActionListener(e1 -> {
                    try {
                        cCar.createCar(1, conn);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                });*/
            });


            //if(true) {
            //veh.addActionListener(this::ZZZZZZZZZZZZZZ);
            //}
            //Start
            JButton start = new JButton("Start");
            ctrP.add(start);
            start.addActionListener(e -> {
            });

            //Stop
            JButton stop = new JButton("Stop");
            ctrP.add(stop);
            //	stop.addActionListener(e -> simTimer.stop());
            //Stress test

            JButton StressTest = new JButton("Stress Test");
            ctrP.add(StressTest);

            StressTest.addActionListener(e -> {

                JFrame ST = new JFrame("Stress Test Menu");

                JButton Spawn = new JButton("Start spawning");

                SpinnerNumberModel pfeil = new SpinnerNumberModel(100, 0, null, 10);
                JSpinner Spinner = new JSpinner(pfeil);

                //JLabel aLabel = new Jlabel("Amount: ");

                //JPanel row = new JPanel(new java.awt);

                int amount = (int) Spinner.getValue();
                ST.setSize(500, 300);


                ST.add(Spawn);
                ST.setVisible(true);
                ST.setSize(250, 150);
                ST.add(Spinner);
                ST.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                ST.setVisible(true);
            });

            JButton vehtype = new JButton("Filter");
            ctrP.add(vehtype);

            vehtype.addActionListener(e -> {
                JFrame vFrm = new JFrame("Choose Vehicle Type");
                vFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                JCheckBox car = new JCheckBox("Car");
                JCheckBox bus = new JCheckBox("Bus");
                JCheckBox motorcycle = new JCheckBox("Motorcycle");
                JCheckBox pedestrian = new JCheckBox("Pedestrian");
                JCheckBox cyclist = new JCheckBox("Cyclist");
                JCheckBox allV = new JCheckBox("All Moving Objects");

                Font sizeFont = new Font("Dialog", Font.PLAIN, 20);

                car.setFont(sizeFont);
                bus.setFont(sizeFont);
                motorcycle.setFont(sizeFont);
                pedestrian.setFont(sizeFont);
                cyclist.setFont(sizeFont);
                allV.setFont(sizeFont);

                var distance = BorderFactory.createEmptyBorder(10, 20, 10, 20);

                car.setBorder(distance);
                bus.setBorder(distance);
                motorcycle.setBorder(distance);
                pedestrian.setBorder(distance);
                cyclist.setBorder(distance);
                allV.setBorder(distance);


                car.setSelected(true);
                bus.setSelected(true);
                motorcycle.setSelected(true);
                pedestrian.setSelected(true);
                cyclist.setSelected(true);
                allV.setSelected(true);

                JPanel panel = new JPanel();
                panel.setLayout(new java.awt.GridLayout(6, 1, 10, 10));

                panel.add(car);
                panel.add(bus);
                panel.add(motorcycle);
                panel.add(pedestrian);
                panel.add(cyclist);
                panel.add(allV);

                vFrm.setContentPane(panel);
                vFrm.setSize(500, 300);
                vFrm.setVisible(true);

                car.addActionListener(e1 -> {
                    if (car.isSelected() == false) {
                        allV.setSelected(false);
                    }
                });

                bus.addActionListener(e1 -> {
                    if (bus.isSelected() == false) {
                        allV.setSelected(false);
                    }
                });

                motorcycle.addActionListener(e1 -> {
                    if (motorcycle.isSelected() == false) {
                        allV.setSelected(false);
                    }
                });

                pedestrian.addActionListener(e1 -> {
                    if (pedestrian.isSelected() == false) {
                        allV.setSelected(false);
                    }
                });

                cyclist.addActionListener(e1 -> {
                    if (cyclist.isSelected() == false) {
                        allV.setSelected(false);
                    }
                });

                car.addActionListener(e1 -> {
                    if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                        allV.setSelected(true);
                    }
                });

                bus.addActionListener(e1 -> {
                    if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                        allV.setSelected(true);
                    }
                });

                motorcycle.addActionListener(e1 -> {
                    if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                        allV.setSelected(true);
                    }
                });

                pedestrian.addActionListener(e1 -> {
                    if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                        allV.setSelected(true);
                    }
                });

                cyclist.addActionListener(e1 -> {
                    if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                        allV.setSelected(true);
                    }
                });

                allV.addActionListener(e1 -> {
                    if (allV.isSelected() == false) {
                        car.setSelected(false);
                        bus.setSelected(false);
                        motorcycle.setSelected(false);
                        pedestrian.setSelected(false);
                        cyclist.setSelected(false);
                    } else if (allV.isSelected() == true) {
                        car.setSelected(true);
                        bus.setSelected(true);
                        motorcycle.setSelected(true);
                        pedestrian.setSelected(true);
                        cyclist.setSelected(true);
                    }
                });


                cyclist.addActionListener(f -> {
                    if (mv == null) return;

                    //	Edges edg = mv.getEdges().get(0);
                    //	vMngr.spawnVehicle(1, conn, 'C');
                    //smV.repaint();
                });

            });


            JMenuBar menuBar = new JMenuBar();
            frame.setJMenuBar(menuBar);
            //FileMenu
            JMenu fileMenu = new JMenu("file");
            JMenuItem openItem = new JMenuItem("Open");
            JMenuItem exitItem = new JMenuItem("Exit");
            fileMenu.add(openItem);
            fileMenu.addSeparator();
            fileMenu.add(exitItem);
            menuBar.add(fileMenu);


            //FileChooser
            openItem.addActionListener(e -> openNtwrkFile());
            exitItem.addActionListener(e -> System.exit(0));

            frame.setLocationRelativeTo(null);
            frame.setVisible(true);


        }


        //For choosing your network
        private void openNtwrkFile() {
            JFileChooser filechoose = new JFileChooser();
            filechoose.setDialogTitle("Open SUMO network");
            filechoose.setFileFilter(new FileNameExtensionFilter("SUMO network (*.net.xml)", "xml"));

            int rslt = filechoose.showOpenDialog(frame);
            if (rslt == JFileChooser.APPROVE_OPTION) {
                File selectedFile = filechoose.getSelectedFile();
                new ParseNetwork(center, selectedFile).execute();
                fileLoaded = true;
            }
            if (rslt == JFileChooser.CANCEL_OPTION) {
            }
        }

        public void startVisual() {

            //smV.repaint();
        }

        public void simulateMapVisual() {

            //smV.repaint();
        }

        public void setMapVisual(MapVisual mv2) {
            this.mv = mv2;
        }


    }