package src;
import de.tudresden.sumo.cmd.Simulation;
import it.polito.appeal.traci.SumoTraciConnection;
import de.tudresden.sumo.cmd.Vehicle;

public class VehicleModul {


    public String id;
    public String type;
    public String routeID;
    public int depart;
    public double position;
    public double speed;
    public byte departLane;



    public VehicleModul(String id) {
        this.id = id;
        this.speed = 0.0;
        this.position = 0.0;
        this.routeID = "";
        this.depart = 0;
        this.departLane = 0;
        this.type = "";

    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public double getPosition() {
        return position;
    }

    public void setPosition(double position) {
        this.position = position;
    }


    public void updateFromSumo(SumoTraciConnection conn) throws Exception {
        synchronized (LOCK.CONN_LOCK)
        {
            this.speed = (double) conn.do_job_get(
                    Vehicle.getSpeed(this.id)
            );
        }
        synchronized (LOCK.CONN_LOCK)
        {
            this.position = (double) conn.do_job_get(
                    Vehicle.getPosition(this.id)
            );
        }
    /*this.lane = (String) conn.do_job_get(
            Vehicle.getLaneID(this.id)
    );*/
    }
    public void setSpeedINSumo(SumoTraciConnection conn, double newSpeed) throws Exception{
        this.speed = newSpeed;
        synchronized (LOCK.CONN_LOCK)
        {
            conn.do_job_set(
                    Vehicle.setSpeed(this.id, newSpeed)
            );
        }
    }

}
//T0= Bus , T1= Motorrad, T2 = Fahrrad, T3= Menschen, T4= Auto
