/**
 * 
 */
/**
 * 
 */
module SumoJP {
	requires java.desktop;
	requires TraaS;
	requires java.xml;
}