package main;

import it.polito.appeal.traci.SumoTraciConnection;
import de.tudresden.sumo.cmd.Trafficlight;

public class TrafficlightModul {

    public String id;
    protected String state;
    protected int phase; // aktuelle Ampelphase
    protected double phasetime;
    protected double nextPhase; //Zeipunkt nächster Wechsel der Phase
    protected String multiPhase; //Steuert in einem String mehrere Ampelphasen. Mehrerer Lanes z.B geradeaus, linksabbieger etc.
    public TrafficlightModul(String id ) {
        this.id = id;
    }

    /*public void tauschen(String id, String state, SumoTraciConnection conn) {
        TrafficlightModul t = new TrafficlightModul(id, state);
        conn.do_job_set(Vehicle.add(c.id, c.type, c.routeID, c.depart, c.position, c.speed, c.departLane));

    }
    /*GGgGGgGgrrrr 12 J1
    rrrrGGgGGgGg 12 J2
    GGGGrrr 7 J22
    GgrrrGGG 8 J23
    GGggGgrrrrrGGgGg 16 J26
    rrrrGGgGGgGg 12 J3
    rrrrGGgGGgGg 12 J47
    rGGr  4   J8*/
    
  //Hast hier einen 2ten Konstruktor
   /* TrafficlightModul(){
        this.id = id;
    }*/
    public String getId(){
        return id;
    }
    public int getPhase(){
        return phase;
    }
    public String getMultiPhase(){
        return multiPhase;
    }

   /* public void updateFromSumo(SumoTraciConnection conn) throws Exception {
        this.phase = (int) conn.do_job_get(
                Trafficlight.getPhase(this.id)
        );
        this.phasetime = (double) conn.do_job_get(
                Trafficlight.getPhaseDuration(this.id)
        );
        this.nextPhase = (double) conn.do_job_get(
                Trafficlight.getNextSwitch(this.id)
        );
        this.multiPhase = (String) conn.do_job_get(
                Trafficlight.getRedYellowGreenState(this.id)
        );
    }

    public void setPhase(SumoTraciConnection conn, int neuePhase) throws Exception{
        conn.do_job_set(
                Trafficlight.setPhase(this.id, neuePhase)
        );
        this.phase = neuePhase;
    }
    public void setPhasetime(SumoTraciConnection conn, double neuePhasetime ) throws Exception{
        conn.do_job_set(
                Trafficlight.setPhaseDuration(this.id, neuePhasetime)
        );
    }
*/    public void setMultiPhase(SumoTraciConnection conn, String neueMultiphase) throws Exception {
       synchronized (LOCK.CONN_LOCK) {
           conn.do_job_set(
                   Trafficlight.setRedYellowGreenState(this.id, neueMultiphase)
           );
       }
   }
}
