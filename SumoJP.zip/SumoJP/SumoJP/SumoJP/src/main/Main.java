package main;

import it.polito.appeal.traci.SumoTraciConnection;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import GUI_Java.Gui;
import GUI_Java.JunctionGui;
import GUI_Java.LanesGui;
import GUI_Java.MapVisual;
import GUI_Java.ParseElmt;
import GUI_Java.Simulation;
import GUI_Java.VehicleManager;

public class Main {
	public static void main(String[] args) throws Exception {
		
        String SUMO_BIN = "C:\\Users\\velib\\Desktop\\Java\\sumo-win64-1.25.0\\sumo-1.25.0\\bin\\sumo-gui.exe";
        String SUMO_CFG = "C:\\Users\\velib\\Downloads\\TestM2.sumocfg";
        String SUMO_NET = "C:\\Users\\velib\\Downloads\\TestM2.net.xml";
       
        SumoTraciConnection	conn = new SumoTraciConnection(SUMO_BIN, SUMO_CFG);
        conn.addOption("start", "true");
        conn.runServer();
 
        //Create MapViual class
        MapVisual mv = new MapVisual();
        
        //Parse Map
        ParseElmt parser = new ParseElmt(new File(SUMO_NET));
        parser.parse();
        mv.setBounds(parser.getMinX(), parser.getMinY(), parser.getMaxX(), parser.getMaxY());
        List<LanesGui> allLanes = parser.getEdges().stream().flatMap(e -> e.lnlst.stream()).toList();
        mv.setLanes(allLanes);
        List<JunctionGui> allJunctions = new ArrayList<>(parser.getJunc().values());
        mv.setJunctions(allJunctions);
        
        VehicleManager vhcM = new VehicleManager(mv);
        
        //Create Silulatin class (for gui)
        Simulation simu = new Simulation(conn, mv, vhcM);
        
        //Starting the GUI and the Visualization
        SwingUtilities.invokeLater(() -> {
            Gui gui = new Gui(conn,mv,simu, vhcM);
            gui.startFrame();
            gui.setMapVisual(mv);
            mv.revalidate();
            mv.repaint();
        });

        //Start a simu Thread
        Thread simuThread = new Thread(simu);
        simuThread.start(); 
        
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                simu.stop();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }));
    }
	
}