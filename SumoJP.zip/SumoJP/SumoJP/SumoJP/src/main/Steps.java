package main;

import de.tudresden.sumo.cmd.Trafficlight;
import de.tudresden.sumo.cmd.Vehicle;
import de.tudresden.sumo.objects.SumoStringList;
import it.polito.appeal.traci.SumoTraciConnection;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Steps {

    private int time = 0;

    private int currentVehicleCount = 0;
    private int maxVehicleCount = 0;

    private final Map<String, String> trafficLightStates = new HashMap<>();

    public Steps() {
    }

    public void update(SumoTraciConnection conn) throws Exception {

        time++;

        SumoStringList vehIds = (SumoStringList) conn.do_job_get(Vehicle.getIDList());

        currentVehicleCount = vehIds.size();

        if (currentVehicleCount > maxVehicleCount) {
            maxVehicleCount = currentVehicleCount;
        }

        SumoStringList tlIds = (SumoStringList) conn.do_job_get(Trafficlight.getIDList());

        for (String id : tlIds) {
            String state = (String) conn.do_job_get(Trafficlight.getRedYellowGreenState(id));
            trafficLightStates.put(id, state);
        }
    }

    public int getTime() {
        return time;
    }

    public int getCurrentVehicleCount() {
        return currentVehicleCount;
    }

    public int getMaxVehicleCount() {
        return maxVehicleCount;
    }

    public Map<String, String> getTrafficLightStates() {
        return trafficLightStates;
    }

    public void reset() {
        time = 0;
        currentVehicleCount = 0;
        maxVehicleCount = 0;
        trafficLightStates.clear();
    }
}