package GUI_Java;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;

import de.tudresden.sumo.cmd.*;
import de.tudresden.sumo.objects.SumoColor;
import de.tudresden.sumo.objects.SumoPosition2D;
import de.tudresden.sumo.objects.SumoStringList;

import java.util.List;
import java.util.Map;

import javax.swing.SwingUtilities;

import it.polito.appeal.traci.SumoTraciConnection;
import main.Steps;
import main.VehicleModul;

public class Simulation implements Runnable {

    private volatile boolean running = false;
    private volatile boolean paused = true;

    private final SumoTraciConnection conn;
    private final MapVisual map;

    private int time = 0;
    private int highestVehicleCount = 0;
    private final Steps steps = new Steps();
    
    public Simulation(SumoTraciConnection conn, MapVisual map) {
        this.conn = conn;
        this.map = map;
    }

    public void play()  { paused = false; }
    public void pause() { paused = true;  }
    public void stop()  { paused = true; running = false; }

    public int getTime() { return time; }
    public int getHighestVehicleCount() { return highestVehicleCount; }

    @Override
    public void run() {
        running = true;

        try {
            while (running ) {

            	if (conn.isClosed()) {
                    System.out.println("SUMO connection closed, stopping simulation loop.");
                    break;
                }
            	
                if (!paused) {
                    conn.do_timestep();
                    steps.update(conn);
                    time++;
                    
                    updateMap();
                }

                Thread.sleep(50); 
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally { System.out.println("Simulation thread exiting...");}
    }

    
    
    //Vehicles
	private void updateMap() throws Exception {
	    List<VehicleGui> vehList = new ArrayList<>();

	    SumoStringList vehIDs = (SumoStringList) conn.do_job_get(Vehicle.getIDList());
	    Map<String,VehicleGui> sumoVhc = new HashMap<>();
	    for (String idV : vehIDs) {
	        String typeV = (String) conn.do_job_get(Vehicle.getTypeID(idV));
	        SumoPosition2D posV = (SumoPosition2D) conn.do_job_get(Vehicle.getPosition(idV));
	        SumoColor colorV = (SumoColor) conn.do_job_get(Vehicle.getColor(idV));
	        VehicleGui vhc = new VehicleGui(idV, typeV, colorV, posV.x, posV.y);
	        vehList.add(vhc);
	        sumoVhc.put(idV,vhc);
	    }
	    

    	//Traffic Lights
    	List<TrafficLightsGui> tlList = new ArrayList<>();
    	SumoStringList tlIDs = (SumoStringList) conn.do_job_get(Trafficlight.getIDList());
    	for (String idTL : tlIDs) {
    		String state = (String) conn.do_job_get(Trafficlight.getRedYellowGreenState(idTL));
    		int phase = (int) conn.do_job_get(Trafficlight.getPhase(idTL));
    		SumoPosition2D posTL = (SumoPosition2D) conn.do_job_get(Junction.getPosition(idTL));

    		TrafficLightsGui.TLColor color;
    		if (state.toUpperCase().contains("G")) { color = TrafficLightsGui.TLColor.GREEN; }
    		else if (state.toUpperCase().contains("Y")) { color = TrafficLightsGui.TLColor.YELLOW; }
    		else if (state.toUpperCase().contains("R")) { color = TrafficLightsGui.TLColor.RED; }
    		else { color = TrafficLightsGui.TLColor.GREY; }
    		tlList.add(new TrafficLightsGui(idTL, posTL.x, posTL.y, color, phase, state));
    	}
        SwingUtilities.invokeLater(() -> {
            map.setVehicles(vehList);
            map.setTrafficLights(tlList);
            map.repaint();
        });
        
        int crntVhc = vehList.size();
    	if (crntVhc > highestVehicleCount) highestVehicleCount = crntVhc;
    }


    public void nextPhase(String tlId) throws Exception {
        int current = (int) conn.do_job_get( Trafficlight.getPhase(tlId));
        int maxPhase = (int) conn.do_job_get(Trafficlight.getProgram(tlId));
        conn.do_job_set(Trafficlight.setPhase(tlId, ((current + 1) % maxPhase)));
    }

    public void setPhase(String tlId, int phase) throws Exception {
    	int maxPhase = (int) conn.do_job_get(Trafficlight.getProgram(tlId));
        if (phase < 0 || phase >= maxPhase) throw new IllegalArgumentException("Invalid phase");
    	conn.do_job_set(Trafficlight.setPhase(tlId, phase));
    }

}
