package GUI_Java;

import java.awt.Color;

import de.tudresden.sumo.objects.SumoColor;

public class VehicleGui {

	    public String id;
	    public String type;
	    public double x,y; 
	    public SumoColor color;

	    public VehicleGui(String id2, String type2,SumoColor color2, double x2, double y2) {
	        this.id = id2;
	        this.type = type2;
	        this.color = color2;
	        this.x = x2;
	        this.y = y2;
	    }
	    public Color getColor() { 
	    	return new Color(
	    			Byte.toUnsignedInt(color.r),
	    			Byte.toUnsignedInt(color.g),
	    			Byte.toUnsignedInt(color.b),
	    			Byte.toUnsignedInt(color.a)
	    			);
	    }
	    
}
