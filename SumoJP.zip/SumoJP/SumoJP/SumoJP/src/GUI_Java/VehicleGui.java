package GUI_Java;

import java.awt.geom.Point2D;

public class VehicleGui {

	    public String id;
	    public String type;
	    public double x,y; 

	    public EdgesGui crntEdg;
	    public LanesGui crntLane;
	    public int laneIndex = 0; //lane shape point
	    public double speed = 10.0; //x,y for speed
	    
	    public VehicleGui(String id2, String type2, double x2, double y2) {
	        this.id = id2;
	        this.type = type2;
	        this.x = x2;
	        this.y = y2;
	    }
	    
	    //Now he has to drive along the lanes
		public void step(double dt) {    
			x += speed * dt;
	        y += speed * dt;
		}
}
