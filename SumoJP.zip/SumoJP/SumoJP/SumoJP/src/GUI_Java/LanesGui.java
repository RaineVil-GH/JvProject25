package GUI_Java;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class LanesGui {
    public String id;
    public List<Point2D.Double> shape = new ArrayList<>(); 
    public List<LanesGui> neighbour = new ArrayList<>();

    public LanesGui() {}

}



