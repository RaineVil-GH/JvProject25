package GUI_Java;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class LanesGui {
    public String id;
    public List<Point2D.Double> shape = new ArrayList<>(); // list of lane points

    public LanesGui() {}
    
    // Optional helper to get arrays for MapVisual
    public double[] getXArray() {
        double[] xs = new double[shape.size()];
        for (int i = 0; i < shape.size(); i++) xs[i] = shape.get(i).x;
        return xs;
    }

    public double[] getYArray() {
        double[] ys = new double[shape.size()];
        for (int i = 0; i < shape.size(); i++) ys[i] = shape.get(i).y;
        return ys;
    }
}



