package GUI_Java;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import de.tudresden.sumo.cmd.Junction;
import de.tudresden.sumo.objects.SumoPosition2D;
import de.tudresden.sumo.objects.SumoStringList;
import it.polito.appeal.traci.SumoTraciConnection;
import main.Bus;
import main.Car;
import main.Cyclist;
import main.Motorcycle;
import main.Pedestrian;
import main.Steps;
import main.VehicleModul;


public class Gui
{

	private JPanel center = new JPanel(new BorderLayout());
;
	private JFrame frame;
	
	private SumoTraciConnection conn;
	//Vehicle counters
	int steps = 0;
	int nBus = 0;	
	int nCar = 0;
	int nCyc = 0;
	int nMtr = 0;
	int nPds = 0;

	private MapVisual mv;
	
	public boolean play_stop = false;
	public boolean pressed;
    public Simulation simu;

	public VehicleManager vMngr;

	public Gui(SumoTraciConnection conn2, MapVisual mv2, Simulation simu2, VehicleManager vhcM2) {
		this.conn = conn2;
		this.mv = mv2;
		this.simu = simu2;
		vMngr = vhcM2;

	}	//;
	
	//StartingMethode for the GUI
	public void startFrame() {
        frame = new JFrame("GUI Network");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);

        JMenuBar menuBar = new JMenuBar();
      	frame.setJMenuBar(menuBar);
    
      	//FileMenu
      	JMenu fileMenu = new JMenu("File");
     	JMenuItem openItem = new JMenuItem("Open");
   		JMenuItem exitItem = new JMenuItem("Exit");
   		
   		menuBar.add(fileMenu);
   		fileMenu.add(openItem);
      	fileMenu.addSeparator();
      	fileMenu.add(exitItem);
        
        JPanel dbP = new JPanel(new BorderLayout());
    	JPanel ctrP = new JPanel();
    	ctrP.setLayout(new BoxLayout(ctrP,BoxLayout.Y_AXIS));
        
        dbP.setPreferredSize(new Dimension(100,0));
        ctrP.setPreferredSize(new Dimension(100,0));
      

        
        frame.add(dbP,BorderLayout.WEST);
        frame.add(center,BorderLayout.CENTER);
        frame.add(ctrP,BorderLayout.EAST);
        
        //Titles
        dbP.add(new JLabel("Dashboarder"),BorderLayout.NORTH);
        ctrP.add(new JLabel("ControlPanel"),BorderLayout.NORTH);
        
        
        //ControlPanel
        //TrafficLight Controls
        JButton tlControl = new JButton("Traffic Lights");
        ctrP.add(tlControl);

        tlControl.addActionListener(e -> openTLControl());
        
        
        //Add Vehicle
        JButton veh = new JButton("Vehicles");  
        ctrP.add(veh);
        veh.addActionListener(e -> {
        		openVehicleDialog();
        });
        
        JButton vehtype = new JButton("Filter");
        ctrP.add(vehtype);
        
        //Filter
        vehtype.addActionListener(e -> {
        	filteringVehicles();
        });		
        
        //Start and Stops Simu
        JButton start = new JButton("Start");
        ctrP.add(start);
        JButton pause = new JButton("Pause");
        ctrP.add(pause);
        JButton stop = new JButton("Stop");  
        ctrP.add(stop);
        
        start.addActionListener(e -> {
        	if(pressed == false)
            {       
        		pressed = true;
        		simu.play();
        	//	start.setEnabled(false);
        		
            }

        });

        pause.addActionListener(e -> { 
			simu.pause();
    	});	
        
		stop.addActionListener(e -> { 
			simu.stop();		
    	});	
		
		//FileChooser
		//openItem.addActionListener(e -> {System.exit(0);});        
		//exitItem.addActionListener(e -> ));

		
        //Stress Test Default
        JButton stresstesting = new JButton("Stress Test Default");
        stresstesting.setPreferredSize(new Dimension(200,200));

        ctrP.add(stresstesting);
        /*
       StressTestDefault STD1 = new StressTestDefault(conn, 1000);
       stresstesting.addActionListener(e -> {
            STD1.StressTestDefaultStarter();
        });
     	*/
        

        //Stress test

        JButton StressTestConfig = new JButton("Stress Test Configuration");
        StressTestConfig.setPreferredSize(new Dimension(200,200));

        ctrP.add(StressTestConfig);

        StressTestConfig.addActionListener(e -> {
        	stresstesting();
        });
		
		
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		
}
	private void openVehicleDialog() {
		JFrame vFrm = new JFrame("Choose Vehicle");
    	vFrm.setLayout(new GridLayout(3,2));
    	JButton busBtn = new JButton("Add Bus");
    	JButton carBtn = new JButton("Add Car");
    	JButton cyclBtn = new JButton("Add Cyclist");
    	JButton motrBtn = new JButton("Add Motorcycle");
    	JButton pedsBtn = new JButton("Add Pedestrian");
    	
    	vFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        vFrm.setSize(500, 300);
        
        vFrm.add(busBtn);
        vFrm.add(carBtn);
        vFrm.add(cyclBtn);
        vFrm.add(motrBtn);
        vFrm.add(pedsBtn);            
        
        vFrm.setVisible(true);
        
        
        busBtn.addActionListener(f -> {
        	addVehicleGui(new Bus("B" + nBus));
			nBus++;
		});
        carBtn.addActionListener(f -> {
        	addVehicleGui(new Car("C" + nCar));
			nCar++;  
		});
        cyclBtn.addActionListener(f -> {
        	addVehicleGui(new Cyclist("F" + nCyc));
			nCyc++;
		});
        motrBtn.addActionListener(f -> {
        	addVehicleGui(new Motorcycle("M" + nMtr));
			nMtr++;
		});
        pedsBtn.addActionListener(f -> {
        	addVehicleGui(new Pedestrian("P" + nPds));
			nPds++;
		}); 
	}	
	
	private void addVehicleGui(VehicleModul vhc) {
		if(mv == null || vMngr == null) return;
		try {
			LanesGui lane = mv.getLanes().get(0);
			Point2D.Double start = lane.shape.get(0);
			vMngr.addVehicle(vhc, start.x, start.y);
			mv.repaint();
		} catch(Exception e) { e.printStackTrace(); }
	}
	
	public void stresstesting() {
		
		JFrame STC = new JFrame("Stress Test Menu");

        JButton Spawn = new JButton("Start spawning");

        SpinnerNumberModel pfeil = new SpinnerNumberModel(100, 0, null, 10);
        JSpinner Spinner = new JSpinner(pfeil);
        ((JSpinner.DefaultEditor) Spinner.getEditor())
                .getTextField().setColumns(6);

        JLabel aLabel = new JLabel("Amount: ");

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row.add(aLabel);
        row.add(Spinner);

        JPanel panel  =  new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(row);
        panel.add(Spawn);

        STC.setContentPane(panel);
        STC.pack();
        STC.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        STC.setLocationRelativeTo(null);
        STC.setVisible(true);


        int amount = (int) Spinner.getValue();
		
	}
	public void filteringVehicles( ) {
		  JFrame vFrm = new JFrame("Choose Vehicles to filter");
          vFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
          //JToggleButton car = new JToggleButton("Car");
          //JButton car1 = new JButton("Car");
          JCheckBox car = new JCheckBox("Car");
          JCheckBox bus = new JCheckBox("Bus");
          JCheckBox motorcycle = new JCheckBox("Motorcycle");
          JCheckBox pedestrian = new JCheckBox("Pedestrian");
          JCheckBox cyclist = new JCheckBox("Cyclist");
          JCheckBox allV = new JCheckBox("All Vehicles");

          Font sizeFont = new Font("Dialog", Font.PLAIN, 20);

          car.setFont(sizeFont);
          bus.setFont(sizeFont);
          motorcycle.setFont(sizeFont);
          pedestrian.setFont(sizeFont);
          cyclist.setFont(sizeFont);
          allV.setFont(sizeFont);

          var distance = BorderFactory.createEmptyBorder(10, 20, 10, 20);

          car.setBorder(distance);
          bus.setBorder(distance);
          motorcycle.setBorder(distance);
          pedestrian.setBorder(distance);
          cyclist.setBorder(distance);
          allV.setBorder(distance);


          car.setSelected(true);
          bus.setSelected(true);
          motorcycle.setSelected(true);
          pedestrian.setSelected(true);
          cyclist.setSelected(true);
          allV.setSelected(true);

          JPanel vpnl = new JPanel();
          vpnl.setLayout(new GridLayout(6, 1, 10, 10));

          vpnl.add(car);
          vpnl.add(bus);
          vpnl.add(motorcycle);
          vpnl.add(pedestrian);
          vpnl.add(cyclist);
          vpnl.add(allV);

          vFrm.setContentPane(vpnl);
          vFrm.setSize(500, 300);
          vFrm.setVisible(true);



          car.addActionListener(e1 -> {
              if(car.isSelected() == false) {
                  allV.setSelected(false);
              }
          });

          bus.addActionListener(e1 -> {
              if(bus.isSelected() == false) {
                  allV.setSelected(false);
              }
          });

          motorcycle.addActionListener(e1 -> {
              if(motorcycle.isSelected() == false) {
                  allV.setSelected(false);
              }
          });

          pedestrian.addActionListener(e1 -> {
              if(pedestrian.isSelected() == false) {
                  allV.setSelected(false);
              }
          });

          cyclist.addActionListener(e1 -> {
              if(cyclist.isSelected() == false) {
                  allV.setSelected(false);
              }
          });

          car.addActionListener(e1 -> {
              if((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                  allV.setSelected(true);
              }
          });

          bus.addActionListener(e1 -> {
              if((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                  allV.setSelected(true);
              }
          });

          motorcycle.addActionListener(e1 -> {
              if((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                  allV.setSelected(true);
              }
          });

          pedestrian.addActionListener(e1 -> {
              if((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                  allV.setSelected(true);
              }
          });

          cyclist.addActionListener(e1 -> {
              if((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                  allV.setSelected(true);
              }
          });

          allV.addActionListener(e1 -> {
              if(allV.isSelected() == false) {
                  car.setSelected(false);
                  bus.setSelected(false);
                  motorcycle.setSelected(false);
                  pedestrian.setSelected(false);
                  cyclist.setSelected(false);
              } else if (allV.isSelected() == true) {
                  car.setSelected(true);
                  bus.setSelected(true);
                  motorcycle.setSelected(true);
                  pedestrian.setSelected(true);
                  cyclist.setSelected(true);
              }
          });

	}
	public void openTLControl() {
		
		JFrame tlFrame = new JFrame("TrafficLight Control");
		tlFrame.setLayout(new BorderLayout());
		JComboBox<String> tlSelect = new JComboBox();
		for(TrafficLightsGui tl: mv.getTrafficLights()) {
			tlSelect.addItem(tl.id);
		}
		JButton nextPhase = new JButton("Next Phase");
	    JButton setPhase = new JButton("Set Phase 0");

	    nextPhase.addActionListener(e -> {
	        try {
	            simu.nextPhase((String) tlSelect.getSelectedItem());
	        } catch (Exception ex) { ex.printStackTrace(); }
	    });

	    setPhase.addActionListener(e -> {
	        try {
	            simu.setPhase((String) tlSelect.getSelectedItem(), 0);
	        } catch (Exception ex) { ex.printStackTrace(); }
	    });

	    JPanel btns = new JPanel();
	    btns.add(nextPhase);
	    btns.add(setPhase);

	    tlFrame.add(tlSelect, BorderLayout.NORTH);
	    tlFrame.add(btns, BorderLayout.CENTER);

	    tlFrame.pack();
	    tlFrame.setLocationRelativeTo(frame);
	    tlFrame.setVisible(true);
	}
	
	public void setMapVisual(MapVisual mv2) {
		if(center == null) {
	        center = new JPanel(new BorderLayout());
	        frame.add(center, BorderLayout.CENTER); // make sure it’s added
	    }		
		this.mv = mv2;
		center.removeAll();
		mv.setPreferredSize(new Dimension(800, 600));
		center.add(mv2,BorderLayout.CENTER); 
	}
}
