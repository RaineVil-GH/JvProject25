package GUI_Java;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.*;
import de.tudresden.sumo.cmd.Vehicle;
import de.tudresden.sumo.objects.SumoColor;
import it.polito.appeal.traci.SumoTraciConnection;
import main.Bus;
import main.Car;
import main.Cyclist;
import main.LOCK;
import main.Motorcycle;
import main.Pedestrian;
import main.VehicleModul;


public class Gui
{

	private JPanel center = new JPanel(new BorderLayout());

	private JFrame frame;
	
	private SumoTraciConnection conn;
	//Vehicle counters
	int steps = 0;
	int nBus = 0;	
	int nCar = 0;
	int nCyc = 0;
	int nMtr = 0;
	int nPds = 0;
	//Vehicle Color
	private  Map<String, SumoColor> vehicleColorBackup = new HashMap<>();

	private MapVisual mv;
	
	public boolean play_stop = false;
	public boolean pressed;
	public List<String> TrafficLightsIds;
	public int ticks;
	
	private Car cCar = new Car("Car");
	private Bus bBus = new Bus("Bus");
    private Motorcycle mMotorcycle = new Motorcycle("Motorcycle");
    private Cyclist cCyclist = new Cyclist("Cyclist");
    private Pedestrian pPedestrian = new Pedestrian("Pedestrian");
	
    public Simulation simu;


	public Gui(SumoTraciConnection conn2,List<String> trafficLightsIds, MapVisual mv2, Simulation simu2) {
		this.conn = conn2;
	    this.TrafficLightsIds = trafficLightsIds;
		this.mv = mv2;
		this.simu = simu2;
	}	//;
	
	//StartingMethode for the GUI
	public void startFrame() {
        frame = new JFrame("GUI Network");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);

        JMenuBar menuBar = new JMenuBar();
      	frame.setJMenuBar(menuBar);
    
      	//FileMenu
      	JMenu fileMenu = new JMenu("File");
     	JMenuItem openItem = new JMenuItem("Open");
   		JMenuItem exitItem = new JMenuItem("Exit");
   		
   		menuBar.add(fileMenu);
   		fileMenu.add(openItem);
      	fileMenu.addSeparator();
      	fileMenu.add(exitItem);
        
        JPanel dbP = new JPanel(new BorderLayout());
    	JPanel ctrP = new JPanel();
    	ctrP.setLayout(new BoxLayout(ctrP,BoxLayout.Y_AXIS));
        
        dbP.setPreferredSize(new Dimension(100,0));
        ctrP.setPreferredSize(new Dimension(100,0));
      

        
        frame.add(dbP,BorderLayout.WEST);
        frame.add(center,BorderLayout.CENTER);
        frame.add(ctrP,BorderLayout.EAST);
        
        //Titles
        dbP.add(new JLabel("Dashboarder"),BorderLayout.NORTH);
        ctrP.add(new JLabel("ControlPanel"),BorderLayout.NORTH);
        
        
        //ControlPanel
        //TrafficLight Controls
        JButton tlControl = new JButton("Traffic Lights");
        ctrP.add(tlControl);

        tlControl.addActionListener(e -> openTLControl());
        
        
        //Add Vehicle
        JButton veh = new JButton("Vehicles");  
        ctrP.add(veh);
        veh.addActionListener(e -> {
        		openVehicleDialog();
        });
        
        JButton vehtype = new JButton("Filter");
        ctrP.add(vehtype);
        
        //Filter
        vehtype.addActionListener(e -> {
        	filteringVehicles();
        });		
        
        //Start and Stops Simu
        JButton start = new JButton("Start");
        ctrP.add(start);
        JButton pause = new JButton("Pause");
        ctrP.add(pause);
        JButton stop = new JButton("Stop");  
        ctrP.add(stop);
        
        start.addActionListener(e -> {
        	if(pressed == false)
            {       
        		pressed = true;
        		simu.play();
        	//	start.setEnabled(false);
        		
            }

        });

        pause.addActionListener(e -> { 
			simu.pause();
    	});	
        
		stop.addActionListener(e -> { 
			simu.stop();		
    	});	
		
		//FileChooser
		//openItem.addActionListener(e -> {System.exit(0);});        
		//exitItem.addActionListener(e -> ));

		
        //Stress Test Default
        JButton stresstesting = new JButton("Stress Test Default");
        stresstesting.setPreferredSize(new Dimension(200,200));

        ctrP.add(stresstesting);
        
        /*
        	StressTestDefault STD1 = new StressTestDefault(conn, 1000);
        	stresstesting.addActionListener(e -> {
            	STD1.StressTestDefaultStarter();
        	});
     	*/
        

        //Stress test

        JButton StressTestConfig = new JButton("Stress Test Configuration");
        StressTestConfig.setPreferredSize(new Dimension(200,200));

        ctrP.add(StressTestConfig);

        StressTestConfig.addActionListener(e -> {
        	stresstesting();
        });
		
		
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		
}
	private void openVehicleDialog() {
		JFrame vFrm = new JFrame("Choose Vehicle");
        JButton car = new JButton("Add Car");
        JButton bus = new JButton("Add Bus");
        JButton motorcycle = new JButton("Add Motorcyclist");
        JButton cyclist = new JButton("Add Cyclist");
        JButton pedestrian = new JButton("Add Pedestrian");

        JPanel route = new JPanel(new GridLayout(2,1,0,5));
        route.setBorder(BorderFactory.createTitledBorder("Route & Color"));

        JComboBox<String> selectroute = new JComboBox<>(VehicleModul.routes);
        JComboBox<String> selectcolor = new JComboBox<>(VehicleModul.color);

        route.add(selectroute);
        route.add(selectcolor);

        vFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        vFrm.setSize(500, 300);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 3, 10, 10));

        panel.add(car);
        panel.add(bus);
        panel.add(motorcycle);
        panel.add(cyclist);
        panel.add(pedestrian);
        panel.add(route);

        vFrm.setContentPane(panel);
        vFrm.setLocationRelativeTo(frame);
        vFrm.setVisible(true);

        car.addActionListener(e1 -> {
            try {
                String selectrou = (String) selectroute.getSelectedItem();
                String selectcol = (String) selectcolor.getSelectedItem();
                cCar.createCar(1, conn, selectrou, selectcol);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
       
        });

        bus.addActionListener(e1 -> {
            try {
                String selectrou = (String) selectroute.getSelectedItem();
                String selectcol = (String) selectcolor.getSelectedItem();
                bBus.createBus(1, conn, selectrou, selectcol);
            } catch (Exception ex) {
                ex.printStackTrace();;
            }
        });

        motorcycle.addActionListener(e1 -> {
            try {
                String selectrou = (String) selectroute.getSelectedItem();
                String selectcol = (String) selectcolor.getSelectedItem();
                mMotorcycle.createMotorcycle(1, conn, selectrou, selectcol);
            } catch (Exception ex) {
                ex.printStackTrace();;
            }
        });


        cyclist.addActionListener(e1 -> {
            try {
                String selectrou = (String) selectroute.getSelectedItem();
                String selectcol = (String) selectcolor.getSelectedItem();
                cCyclist.createCyclist(1, conn, selectrou, selectcol);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        pedestrian.addActionListener(e1 -> {
            try {
                String selectrou = (String) selectroute.getSelectedItem();
                String selectcol = (String) selectcolor.getSelectedItem();
                pPedestrian.createPedestrian(1, conn, selectrou, selectcol);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
		
	}
	
	public void stresstesting() {
		
		JFrame STC = new JFrame("Stress Test Menu");

        JButton Spawn = new JButton("Start spawning");

        SpinnerNumberModel pfeil = new SpinnerNumberModel(100, 0, null, 10);
        JSpinner Spinner = new JSpinner(pfeil);
        ((JSpinner.DefaultEditor) Spinner.getEditor())
                .getTextField().setColumns(6);

        JLabel aLabel = new JLabel("Amount: ");

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row.add(aLabel);
        row.add(Spinner);

        JPanel panel  =  new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(row);
        panel.add(Spawn);

        STC.setContentPane(panel);
        STC.pack();
        STC.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        STC.setLocationRelativeTo(null);
        STC.setVisible(true);


        int amount = (int) Spinner.getValue();
		
	}
	public void filteringVehicles( ) {
		 JFrame vFrm = new JFrame("Choose Vehicle Type");
         vFrm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         JCheckBox car = new JCheckBox("Car");
         //vMngr.setShowCar(car.isSelected());
         JCheckBox bus = new JCheckBox("Bus");
         JCheckBox motorcycle = new JCheckBox("Motorcycle");
         JCheckBox cyclist = new JCheckBox("Cyclist");
         JCheckBox pedestrian = new JCheckBox("Pedestrian");
         JCheckBox allV = new JCheckBox("All Moving Objects");

         Font sizeFont = new Font("Dialog", Font.PLAIN, 20);

         car.setFont(sizeFont);
         bus.setFont(sizeFont);
         motorcycle.setFont(sizeFont);
         cyclist.setFont(sizeFont);
         pedestrian.setFont(sizeFont);
         allV.setFont(sizeFont);

         var distance = BorderFactory.createEmptyBorder(10, 20, 10, 20);

         car.setBorder(distance);
         bus.setBorder(distance);
         motorcycle.setBorder(distance);
         cyclist.setBorder(distance);
         pedestrian.setBorder(distance);
         allV.setBorder(distance);


         car.setSelected(true);
         bus.setSelected(true);
         motorcycle.setSelected(true);
         cyclist.setSelected(true);
         pedestrian.setSelected(true);
         allV.setSelected(true);

         JPanel panel = new JPanel();
         panel.setLayout(new java.awt.GridLayout(6, 1, 10, 10));

         panel.add(car);
         panel.add(bus);
         panel.add(motorcycle);
         panel.add(cyclist);
         panel.add(pedestrian);
         panel.add(allV);

         vFrm.setContentPane(panel);
         vFrm.setSize(500, 300);
         vFrm.setVisible(true);


         car.addActionListener(e1 -> {
             if (!car.isSelected()) {
                 allV.setSelected(false);
             }
             try {
                 synchronized (LOCK.CONN_LOCK) {
                     @SuppressWarnings("unchecked")
					 List<String> ids = (List<String>) conn.do_job_get(Vehicle.getIDList());
                     for(String id : ids) {
                         if (!id.startsWith("Car")) continue;
                         if(!car.isSelected()) {
                             if(!vehicleColorBackup.containsKey(id)) {
                                 SumoColor now = (SumoColor) conn.do_job_get(Vehicle.getColor(id));
                                 vehicleColorBackup.put(id, now);
                             }
                             conn.do_job_set(Vehicle.setColor(id, new SumoColor(0, 0, 0,0 )));

                         } else {
                             SumoColor now = vehicleColorBackup.get(id);
                             if(now != null) {
                                 conn.do_job_set(Vehicle.setColor(id, now));
                             }
                         }
                     }

                 }
             } catch (Exception ex) {
                 ex.printStackTrace();
             }
             if(mv != null) {
                 mv.repaint();
             }
         });

         bus.addActionListener(e1 -> {
             if (!bus.isSelected()) {
                 allV.setSelected(false);
             }
             try {
                 synchronized (LOCK.CONN_LOCK) {
                     @SuppressWarnings("unchecked")
					 List<String> ids = (List<String>) conn.do_job_get(Vehicle.getIDList());
                     for(String id : ids) {
                         if (!id.startsWith("Bus")) continue;
                         if(!bus.isSelected()) {
                             if(!vehicleColorBackup.containsKey(id)) {
                                 SumoColor now = (SumoColor) conn.do_job_get(Vehicle.getColor(id));
                                 vehicleColorBackup.put(id, now);
                             }
                             conn.do_job_set(Vehicle.setColor(id, new SumoColor(0, 0, 0,0 )));

                         } else {
                             SumoColor now = vehicleColorBackup.get(id);
                             if(now != null) {
                                 conn.do_job_set(Vehicle.setColor(id, now));
                             }
                         }
                     }

                 }
             } catch (Exception ex) {
                 ex.printStackTrace();
             }
             if(mv != null) {
                 mv.repaint();
             }
         });

         motorcycle.addActionListener(e1 -> {
             if (!motorcycle.isSelected()) {
                 allV.setSelected(false);
             }
             try {
                 synchronized (LOCK.CONN_LOCK) {
                     @SuppressWarnings("unchecked")
					 List<String> ids = (List<String>) conn.do_job_get(Vehicle.getIDList());
                     for(String id : ids) {
                         if (!id.startsWith("Motorcycle")) continue;
                         if(!motorcycle.isSelected()) {
                             if(!vehicleColorBackup.containsKey(id)) {
                                 SumoColor now = (SumoColor) conn.do_job_get(Vehicle.getColor(id));
                                 vehicleColorBackup.put(id, now);
                             }
                             conn.do_job_set(Vehicle.setColor(id, new SumoColor(0, 0, 0,0 )));

                         } else {
                             SumoColor now = vehicleColorBackup.get(id);
                             if(now != null) {
                                 conn.do_job_set(Vehicle.setColor(id, now));
                             }
                         }
                     }

                 }
             } catch (Exception ex) {
                 ex.printStackTrace();
             }
             if(mv != null) {
                 mv.repaint();
             }
         });

         cyclist.addActionListener(e1 -> {
             if (!cyclist.isSelected()) {
                 allV.setSelected(false);
             }
             try {
                 synchronized (LOCK.CONN_LOCK) {
                     @SuppressWarnings("unchecked")
					 List<String> ids = (List<String>) conn.do_job_get(Vehicle.getIDList());
                     for(String id : ids) {
                         if (!id.startsWith("Cyclist")) continue;
                         if(!cyclist.isSelected()) {
                             if(!vehicleColorBackup.containsKey(id)) {
                                 SumoColor now = (SumoColor) conn.do_job_get(Vehicle.getColor(id));
                                 vehicleColorBackup.put(id, now);
                             }
                             conn.do_job_set(Vehicle.setColor(id, new SumoColor(0, 0, 0,0 )));

                         } else {
                             SumoColor now = vehicleColorBackup.get(id);
                             if(now != null) {
                                 conn.do_job_set(Vehicle.setColor(id, now));
                             }
                         }
                     }

                 }
             } catch (Exception ex) {
                 ex.printStackTrace();
             }
             if(mv != null) {
                 mv.repaint();
             }
         });

         pedestrian.addActionListener(e1 -> {
             if (!pedestrian.isSelected()) {
                 allV.setSelected(false);
             }
             try {
                 synchronized (LOCK.CONN_LOCK) {
                     @SuppressWarnings("unchecked")
					 List<String> ids = (List<String>) conn.do_job_get(Vehicle.getIDList());
                     for(String id : ids) {
                         if (!id.startsWith("Pedestrians")) continue;
                         if(!pedestrian.isSelected()) {
                             if(!vehicleColorBackup.containsKey(id)) {
                                 SumoColor now = (SumoColor) conn.do_job_get(Vehicle.getColor(id));
                                 vehicleColorBackup.put(id, now);
                             }
                             conn.do_job_set(Vehicle.setColor(id, new SumoColor(0, 0, 0,0 )));

                         } else {
                             SumoColor now = vehicleColorBackup.get(id);
                             if(now != null) {
                                 conn.do_job_set(Vehicle.setColor(id, now));
                             }
                         }
                     }

                 }
             } catch (Exception ex) {
                 ex.printStackTrace();
             }
             if(mv != null) {
                 mv.repaint();
             }
         });

         car.addActionListener(e1 -> {
             if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                 allV.setSelected(true);
             }
         });



         bus.addActionListener(e1 -> {
             if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                 allV.setSelected(true);
             }
         });

         motorcycle.addActionListener(e1 -> {
             if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                 allV.setSelected(true);
             }
         });

         pedestrian.addActionListener(e1 -> {
             if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                 allV.setSelected(true);
             }
         });

         cyclist.addActionListener(e1 -> {
             if ((car.isSelected() == true) && (bus.isSelected() == true) && (motorcycle.isSelected() == true) && (pedestrian.isSelected() == true) && (cyclist.isSelected() == true)) {
                 allV.setSelected(true);
             }
         });

         allV.addActionListener(e1 -> {
             if (!allV.isSelected()) {
                 car.setSelected(false);
                 bus.setSelected(false);
                 motorcycle.setSelected(false);
                 pedestrian.setSelected(false);
                 cyclist.setSelected(false);
             } else {
                 car.setSelected(true);
                 bus.setSelected(true);
                 motorcycle.setSelected(true);
                 pedestrian.setSelected(true);
                 cyclist.setSelected(true);
             }
             try {
                 synchronized (LOCK.CONN_LOCK) {
                     @SuppressWarnings("unchecked")
					 List<String> ids = (List<String>) conn.do_job_get(Vehicle.getIDList());
                     for(String id : ids) {
                         if (!id.startsWith("Car") && !id.startsWith("Bus") && !id.startsWith("Motorcycle") && !id.startsWith("Cyclist") && !id.startsWith("Pedestrians")) continue;
                         if(!allV.isSelected()) {
                             if(!vehicleColorBackup.containsKey(id)) {
                                 SumoColor now = (SumoColor) conn.do_job_get(Vehicle.getColor(id));
                                 vehicleColorBackup.put(id, now);
                             }
                             conn.do_job_set(Vehicle.setColor(id, new SumoColor(0, 0, 0,0 )));

                         } else {
                             SumoColor now = vehicleColorBackup.get(id);
                             if(now != null) {
                                 conn.do_job_set(Vehicle.setColor(id, now));
                             }
                         }
                     }

                 }
             } catch (Exception ex) {
                 ex.printStackTrace();
             }
             if(mv != null) {
                 mv.repaint();
             }
         });

	}
	public void openTLControl() {
		
		JFrame tlFrame = new JFrame("TrafficLight Control");
		tlFrame.setLayout(new BorderLayout());
		JComboBox<String> tlSelect = new JComboBox<String>();
		for(TrafficLightsGui tl: mv.getTrafficLights()) {
			tlSelect.addItem(tl.id);
		}
		JButton nextPhase = new JButton("Next Phase");
	    JButton setPhase = new JButton("Set Phase 0");

	    nextPhase.addActionListener(e -> {
	        try {
	            simu.nextPhase((String) tlSelect.getSelectedItem());
	        } catch (Exception ex) { ex.printStackTrace(); }
	    });

	    setPhase.addActionListener(e -> {
	        try {
	            simu.setPhase((String) tlSelect.getSelectedItem(), 0);
	        } catch (Exception ex) { ex.printStackTrace(); }
	    });

	    JPanel btns = new JPanel();
	    btns.add(nextPhase);
	    btns.add(setPhase);

	    tlFrame.add(tlSelect, BorderLayout.NORTH);
	    tlFrame.add(btns, BorderLayout.CENTER);

	    tlFrame.pack();
	    tlFrame.setLocationRelativeTo(frame);
	    tlFrame.setVisible(true);
	}
	
	public void setMapVisual(MapVisual mv2) {
		if(center == null) {
	        center = new JPanel(new BorderLayout());
	        frame.add(center, BorderLayout.CENTER); // make sure it’s added
	    }		
		this.mv = mv2;
		center.removeAll();
		mv.setPreferredSize(new Dimension(800, 600));
		center.add(mv2,BorderLayout.CENTER); 
	}
}
