package GUI_Java;
import java.util.ArrayList;
import java.util.List;


public class EdgesGui {
    public String id;
    public double x1, y1, x2, y2; 
    public List<LanesGui> lnlst = new ArrayList<>();

    public EdgesGui() {}
}
