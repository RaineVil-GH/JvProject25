package GUI_Java;


public class GuiSumoBridge {
   
	//GUI_JavaProjekt gui = new GUI_JavaProjekt();
	
	public GuiSumoBridge() {
	}

	public void startGui() {
	//	gui.startFrame();
	}

	public void ongoingGui() {
		//gui.simulateMapVisual();
	}

}
