package GUI_Java;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JPanel;



public class MapVisual extends JPanel{
	
	private double minX = 0, minY = 0, maxX = 100, maxY = 100;	
	private double scl = 1.0;

	private List<LanesGui> laneList = new ArrayList<>();
	private List<VehicleGui> vhclist = Collections.synchronizedList(new ArrayList<>()); 
	private List<JunctionGui> juncList = new ArrayList<>();
	private List<TrafficLightsGui> tlList = new ArrayList<>();
	
	//Constructor
	public MapVisual() {
		setBackground(Color.GREEN.darker());		
	}
	
	public void setVehicles(List<VehicleGui> vehList2) {
	    System.out.println("setVehicles called: " + vehList2.size());
		this.vhclist = vehList2;
		repaint();

	}
	public void setLanes(List<LanesGui> laneList2) {
		this.laneList = laneList2;
		updateBounds();
		repaint();
	}
		
	public void setTrafficLights(List<TrafficLightsGui> tlList2) {
	    System.out.println("setVehicles called: " + tlList2.size());
		this.tlList = tlList2;
		repaint();
	}
	
	public void setJunctions(List<JunctionGui> juncList2) {
		this.juncList = juncList2;
		updateBounds();
		repaint();
	}
	
	private void reScale() {
        if (maxX - minX == 0 || maxY - minY == 0) return;
		double sX = getWidth() / (maxX - minX);
		double sY = getHeight() / (maxY - minY);
		scl = Math.min(sX, sY);
	}
	private void updateBounds() {
		if (laneList.isEmpty()) {
            minX = minY = 0;
            maxX = maxY = 100;
            scl = 1.0;
            return;
        }

        minX = Double.MAX_VALUE;
        minY = Double.MAX_VALUE;
        maxX = Double.MIN_VALUE;
        maxY = Double.MIN_VALUE;

        for (LanesGui lane : laneList) {
            for (Point2D.Double pt : lane.shape) {
                minX = Math.min(minX, pt.x);
                minY = Math.min(minY, pt.y);
                maxX = Math.max(maxX, pt.x);
                maxY = Math.max(maxY, pt.y);
            }
        }
        
        for (JunctionGui j : juncList) {
            minX = Math.min(minX, j.x);
            minY = Math.min(minY, j.y);
            maxX = Math.max(maxX, j.x);
            maxY = Math.max(maxY, j.y);
        }

        reScale();
	}
	
	public void setBounds(double minX, double minY, double maxX, double maxY) {
	    this.minX = minX;
	    this.minY = minY;
	    this.maxX = maxX;
	    this.maxY = maxY;
	    reScale();
	}
	
	private Point mapping(double a, double b) {
		int pX = (int) ((a - minX) * scl);
		int pY = (int) (getHeight() - (b - minY) * scl);
		return new Point(pX, pY);
	}
	
	//Painting
	@Override
	protected void paintComponent(Graphics g) {
		System.out.println(
			    "lanes=" + laneList.size() +
			    " vehicles=" + vhclist.size() +
			    " tls=" + tlList.size()
			);
		super.paintComponent(g);
		Graphics2D g2D = (Graphics2D) g;
		g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);		

		drawLanes(g2D);
		drawJunc(g2D);
		drawTrafLght(g2D);
		drawVehicles(g2D);
		
	}
	private void drawLanes(Graphics2D gln) {
		gln.setColor(Color.BLACK);
	    gln.setStroke(new BasicStroke((float) 3.2));
	    for (LanesGui lane : laneList) {
            List<Point2D.Double> pts = lane.shape;
            for (int i = 0; i < pts.size() - 1; i++) {
                Point p1 = mapping(pts.get(i).x, pts.get(i).y);
                Point p2 = mapping(pts.get(i + 1).x, pts.get(i + 1).y);
                gln.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
        }
	}
	private void drawJunc(Graphics2D gJ) {
		gJ.setColor(Color.BLACK);
		gJ.setStroke(new BasicStroke((float) 3.2));
		for(JunctionGui j: juncList) {
			if(j.jlcon.size() < 3) continue;
			Path2D jcon = new Path2D.Double();
			boolean first = true;
			for(Point2D.Double jP: j.jlcon) {
				Point p = mapping(jP.x, jP.y);
				if(first) { 
					jcon.moveTo(p.x, p.y); 
					first = false; 
				}
				else { jcon.lineTo(p.x, p.y); }
			}
			jcon.closePath();
			gJ.fill(jcon);
		}
	}
	
	//Drawing TraffLights
	private void drawTrafLght(Graphics2D gtl) {
		gtl.setStroke(new BasicStroke(2));
		for(TrafficLightsGui tl: tlList) {
					
			switch(tl.state) {
				case GREEN: gtl.setColor(Color.GREEN); break;
				case YELLOW: gtl.setColor(Color.YELLOW); break;
				case RED: gtl.setColor(Color.RED); break;
				default: break;
			}
			
			Point p = mapping(tl.x,tl.y);
			gtl.fillRect(p.x - 4, p.y - 4, 13, 13);
			gtl.setColor(Color.BLACK);
			gtl.drawRect(p.x - 4, p.y - 4, 13, 13);
		}	
	}
	
	//Drawing Vehicle
	private void drawVehicles(Graphics2D gvh) {
		for(VehicleGui v: vhclist) {
			gvh.setColor(v.getColor());
			Point p = mapping(v.x, v.y);
			
			switch(v.type) {
			case "t_2": gvh.fillRect(p.x - 3, p.y - 3, 12, 6); break;	//Bus
			case "t_5": gvh.fillRect(p.x - 3, p.y - 3, 6, 6); break;	//Car
			case "t_3": gvh.fillRect(p.x - 3, p.y - 3, 5, 3); break;	//MotorCycle
			case "t_4": gvh.fillRect(p.x - 3, p.y - 3, 4, 3); break;	//Cyclist
			case "t_1": gvh.fillRect(p.x - 3, p.y - 3, 2, 2); break;	//Pedestrian
			}			
		}		
	}
	
	@Override
	public void invalidate() {
		super.invalidate();
		reScale();
	}

	public List<TrafficLightsGui> getTrafficLights() { return tlList; }
	public List<LanesGui> getLanes() { return laneList; }
}

