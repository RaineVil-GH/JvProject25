package GUI_Java;

import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;



public class ParseElmt {
	private List<EdgesGui> edglst = new ArrayList<>();
	private Map<String,JunctionGui> jmap = new HashMap<>();
	private Map<String, List<TrafficLightsGui>> tlmap = new HashMap<>();
	
	
	private double minX = Double.MAX_VALUE;
	private double minY = Double.MAX_VALUE;
	private double maxX = -Double.MAX_VALUE;
	private double maxY = -Double.MAX_VALUE;
	
	public final File file;
	
	public ParseElmt(File fl) throws ParserConfigurationException, SAXException, IOException {
		this.file = fl;
	}
	
	public void parse() throws ParserConfigurationException, SAXException, IOException {

	    DocumentBuilder docbld = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	    Document d = docbld.parse(file);
	    d.getDocumentElement().normalize();

	 
	    NodeList jncNd = d.getElementsByTagName("junction");
	    for (int k = 0; k < jncNd.getLength(); k++) {
	        Element e = (Element) jncNd.item(k);

	        if ("internal".equals(e.getAttribute("type"))) continue;

	        JunctionGui junc = new JunctionGui();
	        junc.id = e.getAttribute("id");
	        junc.x = Double.parseDouble(e.getAttribute("x"));
	        junc.y = Double.parseDouble(e.getAttribute("y"));

	        jmap.put(junc.id, junc);

	        minX = Math.min(minX, junc.x);
	        minY = Math.min(minY, junc.y);
	        maxX = Math.max(maxX, junc.x);
	        maxY = Math.max(maxY, junc.y);
	    }
	    if (jncNd.getLength() < 1) System.out.println("Junction list is empty");

	    NodeList tlNd = d.getElementsByTagName("tlLogic");
	    if (tlNd.getLength() < 1) System.out.println("TrafficLight list is empty");

	    for (int l = 0; l < tlNd.getLength(); l++) {
	        Element tlEl = (Element) tlNd.item(l);
	        String tlid = tlEl.getAttribute("id");

	        List<TrafficLightsGui> tlList = new ArrayList<>();

	        NodeList phsNd = tlEl.getElementsByTagName("phase");
	        for (int m = 0; m < phsNd.getLength(); m++) {
	            Element phsEl = (Element) phsNd.item(m);

	            double dura = Double.parseDouble(phsEl.getAttribute("duration"));
	            String state = phsEl.getAttribute("state");

	            TrafficLightsGui tl = new TrafficLightsGui();
	            tl.id = tlid;
	            tl.state = convertStateString(state); 
	            tlList.add(tl);
	        }

	        tlmap.put(tlid, tlList);
	    }

	    NodeList edgNd = d.getElementsByTagName("edge");
	    if (edgNd.getLength() < 1) System.out.println("Edge list is empty");

	    for (int i = 0; i < edgNd.getLength(); i++) {
	        Element edgEl = (Element) edgNd.item(i);

	        if ("internal".equals(edgEl.getAttribute("function"))) continue;

	        EdgesGui edg = new EdgesGui();
	        
	        String from = edgEl.getAttribute("from");
	        String to = edgEl.getAttribute("to");
	        
	        JunctionGui fromJ = jmap.get(from);
	        JunctionGui toJ = jmap.get(to);
	        
	        edg.id = edgEl.getAttribute("id");
	        edg.lnlst = new ArrayList<>();

	        // Parsing lanes
	        NodeList lnNd = edgEl.getElementsByTagName("lane");
	        if (lnNd.getLength() < 1) System.out.println("Lane list is empty for edge " + edg.id);

	        for (int j = 0; j < lnNd.getLength(); j++) {
	            Element lnEl = (Element) lnNd.item(j);

	            LanesGui ln = new LanesGui();
	            ln.id = lnEl.getAttribute("id");
	            ln.shape = new ArrayList<>();

	            String shp = lnEl.getAttribute("shape").trim();
	            String[] points = shp.split("\\s+");

	            for (String pt : points) {
	                String[] coords = pt.split(",");
	                if (coords.length != 2) continue;

	                double px = Double.parseDouble(coords[0]);
	                double py = Double.parseDouble(coords[1]);

	                ln.shape.add(new Point2D.Double(px, py));

	                minX = Math.min(minX, px);
	                minY = Math.min(minY, py);
	                maxX = Math.max(maxX, px);
	                maxY = Math.max(maxY, py);
	            }

	            if (!ln.shape.isEmpty()) { 
	            	edg.lnlst.add(ln);
	            	Point2D.Double fromP = ln.shape.get(0);
	            	Point2D.Double toP = ln.shape.get(ln.shape.size() - 1);
	            	
	            	if(fromJ != null) fromJ.jlcon.add(fromP);
	            	if(toJ  != null) toJ.jlcon.add(toP);
	            }
	        }

	        edglst.add(edg);
	    }

	    
	    for (JunctionGui jnc : jmap.values()) {
	        if (jnc.id == null || jnc.id.isEmpty()) continue;

	        List<TrafficLightsGui> lights = tlmap.get(jnc.id);
	        if (lights == null) continue;

	        for (TrafficLightsGui tl : lights) {
	            tl.juncTL = jnc;  
	        }
	    }
	   
	    
	}

	private TrafficLightsGui.TLColor convertStateString(String state) {
	    if (state.toUpperCase().contains("G")) return TrafficLightsGui.TLColor.GREEN;
	    else if (state.toUpperCase().contains("Y")) return TrafficLightsGui.TLColor.YELLOW;
	    else if (state.toUpperCase().contains("R")) return TrafficLightsGui.TLColor.RED;
	    else return TrafficLightsGui.TLColor.RED;
	}
	
	public List<EdgesGui> getEdges() { return edglst; }
	public Map<String,JunctionGui> getJunc() { return jmap; }
	
	public Map<String,List<TrafficLightsGui>> getTrffcLght(){ return tlmap; }

	public double getMinX( ) {return minX;}
	public double getMinY( ) {return minY;}
	public double getMaxX( ) {return maxX;}
	public double getMaxY( ) {return maxY;}

}
