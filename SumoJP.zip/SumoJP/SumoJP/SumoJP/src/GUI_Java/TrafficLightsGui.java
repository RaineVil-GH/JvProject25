package GUI_Java;

import java.util.List;

public class TrafficLightsGui {
    public String id;
    public double x, y;
    public TLColor state; // current color
    public int phase;
    public String stateList;
    public JunctionGui juncTL; // link to junction
    // public List<TLPhase> phs = new ArrayList<>(); // optional: phases

    public enum TLColor {
        RED, YELLOW, GREEN, GREY
    }
    public TrafficLightsGui() {}
	public TrafficLightsGui(String idTL, double x2, double y2, TLColor color, int phase2, String stateList2) {
		 this.id = idTL;
		 this.x = x2;
		 this.y = y2;
		 this.state = color;
		 this.phase = phase2;
		 this.stateList = stateList2;
	}
}
