package GUI_Java;

public class JunctionGui {
	String id;
	double x;
	double y;
		
	public JunctionGui() {}

	public JunctionGui(String id2, double x2, double y2)  {
		this.id = id2;
		this.x = x2;
		this.y = y2;
	}
}