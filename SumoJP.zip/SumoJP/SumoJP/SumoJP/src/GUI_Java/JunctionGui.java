package GUI_Java;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

public class JunctionGui {
	public String id;
	public double x;
	public double y;
	public List<Point2D.Double> jlcon = new ArrayList<>();
	public JunctionGui() {}

	public JunctionGui(String id2, double x2, double y2)  {
		this.id = id2;
		this.x = x2;
		this.y = y2;
	}
}