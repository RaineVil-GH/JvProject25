package GUI_Java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import it.polito.appeal.traci.SumoTraciConnection;

public class VehicleManager {
	
	public SumoTraciConnection conn;
	
	private List<VehicleGui> vhclist = Collections.synchronizedList(new ArrayList<>()); 
	public VehicleManager() {
	}
	
	public List<VehicleGui> getVehicle(){ return vhclist; }
	
}	//End of class VehicleManager

