package GUI_Java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.SwingUtilities;

import de.tudresden.sumo.cmd.Vehicle;
import it.polito.appeal.traci.SumoTraciConnection;
import main.*;

public class VehicleManager {
	
	public SumoTraciConnection conn;
	
	private List<VehicleGui> vhclist = Collections.synchronizedList(new ArrayList<>()); 
	private MapVisual mv;
	public VehicleManager(MapVisual mv2) {
		this.mv = mv2;
	}
	
	public void step(double dt) {
	    
		synchronized(vhclist){
			for (VehicleGui v : vhclist) {
		        v.step(dt);
			}
	    }
	}
	
	public void addVehicle(VehicleModul vhc, double x, double y) throws Exception 
	{ 
		VehicleGui vhcgui = new VehicleGui(vhc.getId(),vhc.getType(),x ,y); 
		vhclist.add(vhcgui);
		mv.setVehicles(vhclist);
	}

	public List<VehicleGui> getVehicle(){ return vhclist; }
	
}	//End of class VehicleManager

