package GUI_Java;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;



public class ParseNetwork {

	private final File file;
	private final Gui gui;
	
	public ParseNetwork(Gui guiOut, File flOut){ 
		this.file = flOut; 
		this.gui = guiOut;
	}
	public void prsNtw() throws ParserConfigurationException, SAXException, IOException {
		
			ParseElmt prs = new ParseElmt(file);
			prs.parse();
			/*
			MapVisual mvPanel = new MapVisual(
					prs.getEdges(),
					prs.getJunc(),
					prs.getTrffcLght(),
					prs.getMinX(),
					prs.getMinY(),
					prs.getMaxX(),
					prs.getMaxY()
					);		
			gui.setMapVisual(mvPanel);
			*/
	}
}