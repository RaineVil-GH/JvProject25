package GUI_Java;


public class GuiSumoBridge {
   
	
	public GuiSumoBridge() {
	}

	public void startGui() {
		new GUI_JavaProjekt().startFrame();
		new GUI_JavaProjekt().startVisual();
	}

	public void ongoingGui() {
		new GUI_JavaProjekt().simulateMapVisual();
	}

}
