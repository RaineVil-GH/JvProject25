package GUI_Java;

public class VehicleGUI {

	    public String id;
	    public Edges crntEdg;
	    public int crntLnIdx;
	    public double pos; // distance along the lane
	    public double maxSpd;

	    public VehicleGUI(String id, Edges edge, int laneIdx, double maxSpeed) {
	        this.id = id;
	        this.crntEdg = edge;
	        this.crntLnIdx = laneIdx;
	        this.pos = 0;       		// start at beginning of lane
	        this.maxSpd = maxSpeed; 	// can be set later
	    }
	    
	    public void step(double dt) {
	    	pos += maxSpd * dt;
	    }

}
