/**
 * 
 */
/**
 * 
 */
module SumoJP {
	requires java.desktop;
}