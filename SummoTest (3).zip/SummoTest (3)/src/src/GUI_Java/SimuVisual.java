package src.GUI_Java;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.util.HashMap;
import java.util.Map;

import src.Steps.*;
import javax.swing.JPanel;
@SuppressWarnings("serial")
public class SimuVisual extends JPanel{

	private Map<String,TrafficLights> tlmap;
	private VehicleManager vm;
	
	double minX, minY, maxX, maxY;

						
	//Constructor
	public SimuVisual(Map<String,TrafficLights> tlmapOUT, VehicleManager vmOUT, double minOUTX,double minOUTY,double maxOUTX,double maxOUTY) {
		this.tlmap = tlmapOUT != null ? tlmapOUT : new HashMap<>();
		this.vm = vmOUT != null ? vmOUT : new VehicleManager();
		
		this.minX = minOUTX;
		this.minY = minOUTY;
		this.maxX = maxOUTX;
		this.maxY = maxOUTY;
		
	}
	
	public void paintComponent(Graphics g) {
	
		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(	RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);		
		
		
		double sclX = getWidth() / (maxX - minX);
	    double sclY = getHeight() / (maxY - minY);
	    double scl = Math.min(sclX, sclY);	
		
		drawTrafLght(g2d, scl);
		drawVehicles(g2d, scl);
	}
	
	private void redrawTL(Graphics2D g3, double scl3) {	
		//tlmap.item(0);
		drawTrafLght(g3,scl3);		
	}
	
	private void drawTrafLght(Graphics2D g4, double scl4) {
		int r = 5;
		int spc = 12;
		
		for(TrafficLights jTL: tlmap.values()) {
			if(jTL == null) continue;
			
			String state = jTL.getCrntState();
			if(state == null || state.isEmpty()) continue;
			if(jTL.juncTL == null) continue;
			
			double bX = (jTL.juncTL.x - minX) * scl4;
			double bY = getHeight() - (jTL.juncTL.y - minY) * scl4;
			
			for(int i = 0; i < state.length(); i++) {
				char s = state.charAt(i);
				

				int x = (int) bX + i * spc;
				int y = (int) bY - 15;
				
				g4.setColor(Color.WHITE);
				g4.drawRect(x - r, y - r, r*3 + 1, r*6 + 1);
				g4.setColor(Color.BLACK);
				g4.fillRect(x - r, y - r, r*3 + 1, r*3 + 1);
				
				switch(s) {
				case 'G': g4.setColor(Color.GREEN); break;
				case 'y': g4.setColor(Color.YELLOW); break;
				case 'r': g4.setColor(Color.RED); break;
				default: g4.setColor(Color.GRAY); break;
				}
				
				g4.fillOval(x - r, y - r, r*3, r*3);
			
			}
			
		}
	}
	
	private void drawVehicles(Graphics2D g5, double scl5) {
		int r = 5;
		g5.setColor(Color.WHITE);
		
		if(vm.getVehicle() == null) return;
		
		for(VehicleGUI v : vm.getVehicle()) {
			if(v.crntEdg == null || v.crntEdg.lnlst.isEmpty()) continue;
			
			Lanes lshp = v.crntEdg.lnlst.get(v.crntLnIdx);
			if(lshp.shape.isEmpty()) continue;
			
			int idx = Math.min((int)(v.pos), lshp.shape.size() - 1);
			Point2D vp = lshp.shape.get(idx);
			
			double vX = (vp.getX() - minX) * scl5;
			double vY = getHeight() - (vp.getY() - minY) * scl5;
			
			g5.fillRect((int)vX - r,(int) vY - r, 20, 20);
		}
	}
}
