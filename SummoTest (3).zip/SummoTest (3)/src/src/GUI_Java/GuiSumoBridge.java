package src.GUI_Java;


import it.polito.appeal.traci.SumoTraciConnection;

import java.util.List;

public class GuiSumoBridge {
   private  SumoTraciConnection conn;
   private List<String> TrafficlightsIds;
   private GUI_JavaProjekt gui;

	public GuiSumoBridge() {
	}

	public void startGui(SumoTraciConnection conn, List<String> TrafficLightsIds) {

		this.conn = conn;
		this.TrafficlightsIds = TrafficLightsIds;
		this.gui = new GUI_JavaProjekt(conn);
		this.gui.startFrame(TrafficLightsIds);


		//new GUI_JavaProjekt().startVisual();
	}

	public void ongoingGui() {

		if(gui != null) gui.simulateMapVisual();
	}

}
