package src.GUI_Java;

public class TLPhase {
	
	public double drt;
	public String st;
	
	public TLPhase(double duration , String state) {
		this.drt = duration;
		this.st = state;
	}

}
