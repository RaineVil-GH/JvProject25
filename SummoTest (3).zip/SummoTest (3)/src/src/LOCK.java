package src;

public class LOCK {
    public static final Object CONN_LOCK = new Object();
}
